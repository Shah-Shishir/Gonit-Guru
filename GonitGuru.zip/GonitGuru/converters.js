function volConversion() {
  var from = document.getElementsByName("fVol").value;
  document.getElementById("volConversionResult").innerHTML = from;
}